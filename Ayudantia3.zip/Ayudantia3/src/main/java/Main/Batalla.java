package Main;

import java.util.Random;

public class Batalla {

    public static void main(String[] args) {
        Random rand = new Random();
        NPC jug1 = new NPC("Ragnar", 10, 6, "Vikingo", 100, "Hachas");
        NPC jug2 = new NPC("Rolo", 6, 7, "Asesino", 85, "Dagas");
        NPC ene1 = new NPC("Esqueleto Demoniaco", 4, 4, "Esqueleto", 30, "Daga de huesos");
        NPC ene2 = new NPC("Mago arcano", 9, 6, "Mago", 50, "Necronomicon");
        NPC ene3 = new NPC("Goblin", 3, 5, "Ladrón", 30, "Puñal curvo");
        NPC ene4 = new NPC("Jefe Orco", 8, 3, "Luchador", 80, "Maza con pinchos");

        System.out.println("Llegando al lugar de la misión " + jug1.getNombre() + " se encuentra frente a frente a un " + ene1.getNombre() + " el cual estaba resguardando la entrada con su " + ene1.getArma() + " listo para atacar.");

// Definir orden de los turnos
        NPC primerTurno, segundoTurno;
        if (jug1.getVelocidad() > ene1.getVelocidad()) {
            primerTurno = jug1;
            segundoTurno = ene1;
        } else {
            primerTurno = ene1;
            segundoTurno = jug1;
        }

        while (jug1.getVida() > 0 && ene1.getVida() > 0) {
            // Primer turno
            int daño1 = rand.nextInt(10) + 1;
            int dañoTotal1 = daño1 + primerTurno.getFuerza() + (int) Math.ceil(primerTurno.getVelocidad() / 2.0);
            System.out.println(primerTurno.getNombre() + " hizo " + dañoTotal1 + " puntos de vida a " + segundoTurno.getNombre());
            segundoTurno.setVida(segundoTurno.getVida() - dañoTotal1);
            System.out.println("Ahora " + segundoTurno.getNombre() + " tiene " + segundoTurno.getVida() + " puntos de vida.");

            // Verificar si el segundo turno todavía está vivo
            if (segundoTurno.getVida() > 0) {
                // Segundo turno
                int daño2 = rand.nextInt(10) + 1;
                int dañoTotal2 = daño2 + segundoTurno.getFuerza() + (int) Math.ceil(segundoTurno.getVelocidad() / 2.0);
                System.out.println(segundoTurno.getNombre() + " hizo " + dañoTotal2 + " puntos de vida a " + primerTurno.getNombre());
                primerTurno.setVida(primerTurno.getVida() - dañoTotal2);
                System.out.println("Ahora " + primerTurno.getNombre() + " tiene " + primerTurno.getVida() + " puntos de vida.");
            }
        }
        if (jug1.getVida() > 0) {
            System.out.println("\n"+jug1.getNombre() + " al ganar continuo su travesia adentrandose mas en la cueva que resguardaba el enemigo, mientras avanzaba se pillo con un" + ene2.getNombre()
                    + " acompañado por un " + ene3.getNombre() + " entonces " + jug1.getNombre() + " acompañado con su amigo "
                    + jug2.getNombre() + " deciden ir cada uno por un enemigo distinto");

            if (jug2.getVelocidad() > ene2.getVelocidad()) {
                primerTurno = jug2;
                segundoTurno = ene2;
            } else {
                primerTurno = ene2;
                segundoTurno = jug2;
            }

            while (jug2.getVida() > 0 && ene2.getVida() > 0) {
                // Primer turno
                int daño1 = rand.nextInt(10) + 1;
                int dañoTotal1 = daño1 + primerTurno.getFuerza() + (int) Math.ceil(primerTurno.getVelocidad() / 2.0);
                System.out.println(primerTurno.getNombre() + " hizo " + dañoTotal1 + " puntos de vida a " + segundoTurno.getNombre());
                segundoTurno.setVida(segundoTurno.getVida() - dañoTotal1);
                System.out.println("Ahora " + segundoTurno.getNombre() + " tiene " + segundoTurno.getVida() + " puntos de vida.");

                // Verificar si el segundo turno todavía está vivo
                if (segundoTurno.getVida() > 0) {
                    // Segundo turno
                    int daño2 = rand.nextInt(10) + 1;
                    int dañoTotal2 = daño2 + segundoTurno.getFuerza() + (int) Math.ceil(segundoTurno.getVelocidad() / 2.0);
                    System.out.println(segundoTurno.getNombre() + " hizo " + dañoTotal2 + " puntos de vida a " + primerTurno.getNombre());
                    primerTurno.setVida(primerTurno.getVida() - dañoTotal2);
                    System.out.println("Ahora " + primerTurno.getNombre() + " tiene " + primerTurno.getVida() + " puntos de vida.");
                }
            }
            System.out.println("\n" + "Por otro lado " + jug1.getNombre() + " lucha contra " + ene3.getNombre());
        if (jug1.getVelocidad() > ene3.getVelocidad()) {
            primerTurno = jug1;
            segundoTurno = ene3;
        } else {
            primerTurno = ene3;
            segundoTurno = jug1;
        }

        while (jug1.getVida() > 0 && ene3.getVida() > 0) {
            // Primer turno
            int daño1 = rand.nextInt(10) + 1;
            int dañoTotal1 = daño1 + primerTurno.getFuerza() + (int) Math.ceil(primerTurno.getVelocidad() / 2.0);
            System.out.println(primerTurno.getNombre() + " hizo " + dañoTotal1 + " puntos de vida a " + segundoTurno.getNombre());
            segundoTurno.setVida(segundoTurno.getVida() - dañoTotal1);
            System.out.println("Ahora " + segundoTurno.getNombre() + " tiene " + segundoTurno.getVida() + " puntos de vida.");

            // Verificar si el segundo turno todavía está vivo
            if (segundoTurno.getVida() > 0) {
                // Segundo turno
                int daño2 = rand.nextInt(10) + 1;
                int dañoTotal2 = daño2 + segundoTurno.getFuerza() + (int) Math.ceil(segundoTurno.getVelocidad() / 2.0);
                System.out.println(segundoTurno.getNombre() + " hizo " + dañoTotal2 + " puntos de vida a " + primerTurno.getNombre());
                primerTurno.setVida(primerTurno.getVida() - dañoTotal2);
                System.out.println("Ahora " + primerTurno.getNombre() + " tiene " + primerTurno.getVida() + " puntos de vida.");
            }
        }
            System.out.println("\n" + "Al completar este desafio los heroes se dirigen a una puerta donde esta el lider enemigo"
            + " pero al entrar " + jug2.getNombre() + " es atrapado en una jaula por ende " + jug1.getNombre()
            + " va a enfrentar solo a " + ene4.getNombre());
            
           
        if (jug1.getVelocidad() > ene4.getVelocidad()) {
            primerTurno = jug1;
            segundoTurno = ene4;
        } else {
            primerTurno = ene4;
            segundoTurno = jug1;
        }

        while (jug1.getVida() > 0 && ene4.getVida() > 0) {
            // Primer turno
            int daño1 = rand.nextInt(10) + 1;
            int dañoTotal1 = daño1 + primerTurno.getFuerza() + (int) Math.ceil(primerTurno.getVelocidad() / 2.0);
            System.out.println(primerTurno.getNombre() + " hizo " + dañoTotal1 + " puntos de vida a " + segundoTurno.getNombre());
            segundoTurno.setVida(segundoTurno.getVida() - dañoTotal1);
            System.out.println("Ahora " + segundoTurno.getNombre() + " tiene " + segundoTurno.getVida() + " puntos de vida.");

            // Verificar si el segundo turno todavía está vivo
            if (segundoTurno.getVida() > 0) {
                // Segundo turno
                int daño2 = rand.nextInt(10) + 1;
                int dañoTotal2 = daño2 + segundoTurno.getFuerza() + (int) Math.ceil(segundoTurno.getVelocidad() / 2.0);
                System.out.println(segundoTurno.getNombre() + " hizo " + dañoTotal2 + " puntos de vida a " + primerTurno.getNombre());
                primerTurno.setVida(primerTurno.getVida() - dañoTotal2);
                System.out.println("Ahora " + primerTurno.getNombre() + " tiene " + primerTurno.getVida() + " puntos de vida.");
            }
            if (jug1.getVida() > 0) {
                System.out.println("\n"+jug1.getNombre() + " vence a " + ene4.getNombre());
            } else {
                System.out.println("\n" + ene4.getNombre() + " derrota al heroe");
            }
        }

        } else {
            System.out.println("Aqui termina la travesia de los heroes.");
        }

    }

}
