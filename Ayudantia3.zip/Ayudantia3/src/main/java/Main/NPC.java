
package Main;

public class NPC {
    private String Nombre;
    private int Fuerza;
    private int Velocidad;
    private String clase;
    private int vida;
    private String arma;

    public NPC(String Nombre, int Fuerza, int Velocidad, String clase, int vida, String arma) {
        this.Nombre = Nombre;
        this.Fuerza = Fuerza;
        this.Velocidad = Velocidad;
        this.clase = clase;
        this.vida = vida;
        this.arma = arma;
    }

    public int getVida() {
        return vida;
    }

    public void setVida(int vida) {
        this.vida = vida;
    }

    public String getArma() {
        return arma;
    }

    public void setArma(String arma) {
        this.arma = arma;
    }

    public String getClase() {
        return clase;
    }

    public void setClase(String clase) {
        this.clase = clase;
    }

    public String getNombre() {
        return Nombre;
    }

    public void setNombre(String Nombre) {
        this.Nombre = Nombre;
    }

    public int getFuerza() {
        return Fuerza;
    }

    public void setFuerza(int Fuerza) {
        this.Fuerza = Fuerza;
    }

    public int getVelocidad() {
        return Velocidad;
    }

    public void setVelocidad(int Velocidad) {
        this.Velocidad = Velocidad;
    }
    
}
